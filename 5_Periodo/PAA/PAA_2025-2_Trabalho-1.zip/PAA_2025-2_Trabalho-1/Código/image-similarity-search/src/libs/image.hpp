#pragma once
#include <opencv2/opencv.hpp>
#include <iostream>

class Image 
{
public:
    std::string path;  // Caminho/nome da imagem
    cv::Mat hsv;       // Histograma de Cores (HSV) da imagem

    Image() = default;

    Image(const std::string& imagePath) : path(imagePath) {
        cv::Mat img = cv::imread(imagePath);
        if (img.empty()) {
            std::cerr << "Erro ao ler imagem: " << imagePath << std::endl;
            return;
        }
        extractColorHistogram(img);
    }

    /**
     * 	Extrai o histograma de cores (HSV) de uma imagem
     */
    void extractColorHistogram(const cv::Mat& img) {
        cv::Mat hsvImg;
        cv::cvtColor(img, hsvImg, cv::COLOR_BGR2HSV);

        int h_bins = 50, s_bins = 60;
        int histSize[] = { h_bins, s_bins };
        float h_ranges[] = { 0, 180 };
        float s_ranges[] = { 0, 256 };
        const float* ranges[] = { h_ranges, s_ranges };
        int channels[] = { 0, 1 };

        cv::calcHist(&hsvImg, 1, channels, cv::Mat(), hsv, 2, histSize, ranges, true, false);
        cv::normalize(hsv, hsv, 0, 1, cv::NORM_MINMAX);
    }

    /**
     *  Compara com outra imagem usando histograma
     */
    double compareWith(const Image& other) const {
        return cv::compareHist(hsv, other.hsv, cv::HISTCMP_CORREL);
    }

    /**
     *  Mostra a imagem
     */
    void show() const {
        cv::Mat img = cv::imread(path);
        if (!img.empty()) {
            cv::imshow(path, img);
            cv::waitKey(0);
            cv::destroyWindow(path);
        }
    }
};
