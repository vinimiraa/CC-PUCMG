#ifndef UTILS_HPP
#define UTILS_HPP

bool is_inside(int row, int col, int rows, int cols);
int pixel_index(int row, int col, int cols);

#endif