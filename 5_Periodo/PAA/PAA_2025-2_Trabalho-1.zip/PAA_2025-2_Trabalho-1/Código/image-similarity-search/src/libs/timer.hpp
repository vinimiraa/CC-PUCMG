#pragma once
#include <chrono>
#include <string>
#include <iostream>

class Timer {
private:
    std::chrono::high_resolution_clock::time_point startTime;
    std::chrono::high_resolution_clock::time_point endTime;
    bool running;

public:
    Timer() : running(false) {}

    // Inicia a contagem
    void start() {
        running = true;
        startTime = std::chrono::high_resolution_clock::now();
    }

    // Para a contagem
    void stop() {
        endTime = std::chrono::high_resolution_clock::now();
        running = false;
    }

    // Retorna o tempo decorrido em milissegundos
    double elapsedMilliseconds() const {
        auto end = running ? std::chrono::high_resolution_clock::now() : endTime;
        return std::chrono::duration<double, std::milli>(end - startTime).count();
    }

    // Retorna o tempo decorrido em segundos
    double elapsedSeconds() const {
        auto end = running ? std::chrono::high_resolution_clock::now() : endTime;
        return std::chrono::duration<double>(end - startTime).count();
    }

    // Mostra no console o tempo decorrido com mensagem
    void printElapsed(const std::string& label = "Tempo decorrido") const {
        std::cout << label << ": " << elapsedMilliseconds() << " ms" << std::endl;
    }
};
