#include <iostream>
#include <vector>
#include <stdexcept>
#include "image.hpp"

class List 
{
private:
    std::vector<Image> images;

public:
    List() = default;
    ~List() = default;

    void push_back(const Image& image);
    void push_front(const Image& image);
    void push_at(const Image& image, size_t index);

    Image pop_back();
    Image pop_front();
    Image pop_at(size_t index);

    std::vector<std::pair<std::string, double>> compareSimilarity(const Image& targetImage) const;
};

// Insere uma imagem no final da lista
void List::push_back(const Image& image) {
    images.push_back(image);
}

// Insere uma imagem no início da lista
void List::push_front(const Image& image) {
    images.insert(images.begin(), image);
}

// Insere uma imagem em uma posição específica da lista
void List::push_at(const Image& image, size_t index) 
{
    if (index < images.size()) {
        images.insert(images.begin() + index, image);
    } else {
        images.push_back(image);
    }
}

// Remove a imagem do final da lista
Image List::pop_back() 
{
    if (images.empty()) {
        throw std::out_of_range("Lista vazia");
    }
    Image img = images.back();
    images.pop_back();
    return img;
}

// Remove a imagem do início da lista
Image List::pop_front() 
{
    if (images.empty()) {
        throw std::out_of_range("Lista vazia");
    }
    Image img = images.front();
    images.erase(images.begin());
    return img;
}

// Remove a imagem de uma posição específica da lista
Image List::pop_at(size_t index) 
{
    if (index >= images.size()) {
        throw std::out_of_range("Index fora dos limites");
    }
    Image img = images[index];
    images.erase(images.begin() + index);
    return img;
}

// Compara a imagem de consulta com as imagens da lista e retorna os resultados ordenados
std::vector<std::pair<std::string, double>> List::compareSimilarity(const Image& targetImage) const 
{
    std::vector<std::pair<std::string, double>> results;
    for (const auto& image : images) {
        double score = targetImage.compareWith(image);
        results.push_back({image.path, score});
    }

    std::sort(results.begin(), results.end(),
              [](auto& a, auto& b) { return a.second > b.second; });

    return results;
}
