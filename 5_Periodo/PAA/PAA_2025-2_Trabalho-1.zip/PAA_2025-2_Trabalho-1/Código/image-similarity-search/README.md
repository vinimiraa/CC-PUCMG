<h1 align="center">
   Image Similarity Search
</h1>

<p align="center">
	<img alt="C++ Badge" src="https://img.shields.io/badge/C++-%2300599c?style=for-the-badge&logo=cplusplus&logoColor=white">
  <img alt="Computer Vision Badge" src="https://img.shields.io/badge/Computer%20Vision-%230d1117?style=for-the-badge">
</p>

This project is an **image similarity search tool**. It implements a computer vision technique that analyzes an image's color histogram to find similar images within a dataset.

The program compares the histogram of an input image with the histograms of all other images, ranking them based on their similarity. The images with the most similar color distribution are presented as the most relevant results.

## Quick Start

> [!WARNING]
> This project requires **CMake** and **OpenCV** to be installed on your system.

> To install **CMake** and **OpenCV** on Linux/WSL: `sudo apt update && sudo apt install -y cmake libopencv-dev`

For a quick start, you can clone the repository and run the provided CMake build system.

```bash
git clone https://github.com/giusfds/image-similarity-search
cd image-similarity-search
make all
```

> [!TIP]
> If you prefer not to use CMake, you can compile the code directly with `g++` as shown below.
> ```bash
> g++ -std=c++17 src/*.cpp -Iinclude `pkg-config --cflags --libs opencv4` -o main
> ```

Download sample images and place them in the `images/` directory. Recommended images can be found [here](https://www.kaggle.com/datasets/vishalsubbiah/pokemon-images-and-types?resource=download).

### Usage

To compile and run the project, follow these steps:

1. Build the project using the provided Makefile:
   ```bash
   make all
   ```

2. Run the executable with the desired image as an argument:
   ```bash
   ./main.exe
   ```

## Project Structure
```
image-similarity-search/
├── images/
│   ├── image1.jpg
│   ├── image2.jpg
│   └── image3.jpg
├── src/
│   ├── image.hpp
│   └── main.cpp
├── .gitignore
├── LICENSE
├── Makefile
└── README.md
```