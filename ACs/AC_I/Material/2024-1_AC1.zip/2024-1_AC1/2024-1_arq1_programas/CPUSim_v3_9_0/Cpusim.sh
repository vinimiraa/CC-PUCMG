java -cp ./:CPUSim3.9.jar:jhall.jar:CPUSimHelp3.9.jar cpusim.Main -m SampleAssignments/Wombat1.cpu -t SampleAssignments/W1-0.a
