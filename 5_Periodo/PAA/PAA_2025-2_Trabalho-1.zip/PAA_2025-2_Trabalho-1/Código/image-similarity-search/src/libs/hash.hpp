#include <iostream>
#include <unordered_map>
#include <vector>
#include <algorithm>
#include <stdexcept>
#include "image.hpp"

class HashTable 
{
private:
    std::unordered_map<std::string, Image> table;

public:
    HashTable() = default;
    ~HashTable() = default;

    void insert(const Image& image);
    void remove(const std::string& path);

    std::vector<std::pair<std::string, double>> compareSimilarity(const Image& targetImage) const;
};

// Insere uma imagem na hash (usa o path como chave)
void HashTable::insert(const Image& image) {
    table[image.path] = image;
}

// Remove uma imagem pelo path
void HashTable::remove(const std::string& path) {
    table.erase(path);
}

// Compara a imagem de consulta com as imagens da hash e retorna resultados ordenados
std::vector<std::pair<std::string, double>> HashTable::compareSimilarity(const Image& targetImage) const {
    std::vector<std::pair<std::string, double>> results;

    for (const auto& kv : table) {
        double score = targetImage.compareWith(kv.second);
        results.push_back({kv.first, score});
    }

    std::sort(results.begin(), results.end(),
              [](auto& a, auto& b) { return a.second > b.second; });

    return results;
}
