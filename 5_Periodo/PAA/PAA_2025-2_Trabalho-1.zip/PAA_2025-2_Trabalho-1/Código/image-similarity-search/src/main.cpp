#include <iostream>
#include <vector>
#include <algorithm>
#include "libs/image.hpp"
#include "libs/list.hpp"
#include "libs/hash.hpp"
#include "libs/quadtree.hpp"
#include "libs/timer.hpp"

/**
 * 	Carrega as imagens do dataset e extrai seus histogramas
 */
std::vector<Image> buildDataset(const std::string& folderPath) 
{
    std::vector<cv::String> files;
    cv::glob(folderPath, files, false);

    std::vector<Image> dataset;
    for (const auto& file : files) 
	{
        Image img(file);
        if (!img.hsv.empty()) {
            dataset.push_back(img);
        }
    }

    return dataset;
}

/**
 * 	Mostra os N resultados mais semelhantes
 */
void displayTopResults(
	const std::vector<std::pair<std::string, double>>& results, 
	const std::string& targetImagePath, int topN = 5) 
{
    std::cout << "Top " << topN << " imagens semelhantes a " << targetImagePath << ":\n";
    for (int i = 0; i < std::min(topN, (int)results.size()); i++) {
        std::cout << i+1 << ". " << results[i].first
                  << " (score=" << results[i].second << ")\n";
    }
}

int main(int argc, char *argv[]) 
{
    const std::string folderPath = "images/*.png";

    List list;
    HashTable hashT;
    QuadTree quadT(0, 180, 0, 256); // limites Hue [0,180] e Saturation [0,256]
    Timer timer;

    auto dataset = buildDataset(folderPath);
    if (dataset.empty()) 
	{
        std::cout << "Nenhuma imagem encontrada!" << std::endl;
        return -1;
    }

    for(auto& img : dataset) {
        list.push_back(img);
        hashT.insert(img);
        quadT.insert(img);
    }

    std::string queryPath = "images/pikachu.png";
    Image queryImage(queryPath);
    if (queryImage.hsv.empty()) 
	{
        std::cout << "Erro ao ler imagem de consulta!" << std::endl;
        return -1;
    }

    // --- Lista ---
    timer.start();
    auto list_results = list.compareSimilarity(queryImage);
    timer.stop();
    std::cout << "\n=== Lista ===\n";
    timer.printElapsed("Tempo de busca");
    displayTopResults(list_results, queryPath, 5);

    // --- Hash ---
    timer.start();
    auto hash_results = hashT.compareSimilarity(queryImage);
    timer.stop();
    std::cout << "\n=== Hash ===\n";
    timer.printElapsed("Tempo de busca");
    displayTopResults(hash_results, queryPath, 5);

    // --- Quadtree ---
    timer.start();
    auto qt_results = quadT.compareSimilarity(queryImage);
    timer.stop();
    std::cout << "\n=== Quadtree ===\n";
    timer.printElapsed("Tempo de busca");
    displayTopResults(qt_results, queryPath, 5);

    return 0;
}
