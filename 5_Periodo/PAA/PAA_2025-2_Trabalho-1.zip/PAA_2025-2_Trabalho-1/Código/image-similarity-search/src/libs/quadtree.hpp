#pragma once
#include <iostream>
#include <vector>
#include <algorithm>
#include "image.hpp"

struct QuadNode 
{
    double x, y;          // Coordenadas no espaço (ex: média de Hue e Saturation)
    Image image;          // Imagem armazenada
    QuadNode* nw;         // Noroeste
    QuadNode* ne;         // Nordeste
    QuadNode* sw;         // Sudoeste
    QuadNode* se;         // Sudeste

    QuadNode(double _x, double _y, const Image& _image)
        : x(_x), y(_y), image(_image), nw(nullptr), ne(nullptr), sw(nullptr), se(nullptr) {}
};

class QuadTree 
{
private:
    QuadNode* root;
    double minX, maxX, minY, maxY; // limites da região

    std::pair<double,double> computeCoords(const Image& img) const;

    void insert(QuadNode*& node, double x, double y, const Image& img);
    void collectAll(QuadNode* node, const Image& target, std::vector<std::pair<std::string,double>>& results) const;

public:
    QuadTree(double minX, double maxX, double minY, double maxY);
    ~QuadTree();

    void insert(const Image& img);
    std::vector<std::pair<std::string,double>> compareSimilarity(const Image& targetImage) const;

    void clear(QuadNode* node);
};

// Calcula coordenadas (usando médias simples de Hue e Saturation)
std::pair<double,double> QuadTree::computeCoords(const Image& img) const {
    cv::Scalar meanVal = cv::mean(img.hsv);  
    return { meanVal[0], meanVal[1] }; // Hue, Saturation
}

QuadTree::QuadTree(double _minX, double _maxX, double _minY, double _maxY)
    : root(nullptr), minX(_minX), maxX(_maxX), minY(_minY), maxY(_maxY) {}

QuadTree::~QuadTree() {
    clear(root);
}

void QuadTree::clear(QuadNode* node) {
    if (!node) return;
    clear(node->nw); clear(node->ne);
    clear(node->sw); clear(node->se);
    delete node;
}

void QuadTree::insert(const Image& img) {
    auto [x, y] = computeCoords(img);
    insert(root, x, y, img);
}

void QuadTree::insert(QuadNode*& node, double x, double y, const Image& img) {
    if (!node) {
        node = new QuadNode(x, y, img);
        return;
    }

    if (x < node->x && y < node->y) insert(node->sw, x, y, img);
    else if (x < node->x && y >= node->y) insert(node->nw, x, y, img);
    else if (x >= node->x && y < node->y) insert(node->se, x, y, img);
    else insert(node->ne, x, y, img);
}

void QuadTree::collectAll(QuadNode* node, const Image& target, std::vector<std::pair<std::string,double>>& results) const {
    if (!node) return;

    double score = target.compareWith(node->image);
    results.push_back({node->image.path, score});

    collectAll(node->nw, target, results);
    collectAll(node->ne, target, results);
    collectAll(node->sw, target, results);
    collectAll(node->se, target, results);
}

std::vector<std::pair<std::string,double>> QuadTree::compareSimilarity(const Image& targetImage) const {
    std::vector<std::pair<std::string,double>> results;
    collectAll(root, targetImage, results);

    std::sort(results.begin(), results.end(),
              [](auto& a, auto& b) { return a.second > b.second; });

    return results;
}
